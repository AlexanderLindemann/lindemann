public class Course {
    public Course(int[] ints) {
    }

    String[] finish = new String[4];
    public void doIt(){
        for (int i = 0; i < 3; i++ ){
            if (c[i] >= 5){
                finish[i] = team.getTeamMembers()[i];
            }
        }
    }
}
